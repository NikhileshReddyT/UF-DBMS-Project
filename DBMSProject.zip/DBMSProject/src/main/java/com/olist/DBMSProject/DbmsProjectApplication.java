package com.olist.DBMSProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbmsProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbmsProjectApplication.class, args);
	} 

}
