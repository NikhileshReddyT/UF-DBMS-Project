package com.olist.DBMSProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbmsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
